## MatkulDeweb
<hr/>
Source code ini digunakan untuk mata kuliah design web, silahkan lakukan cloning repository ini atau anda bisa langsung download sebagai zip dikomputer anda<br/>
<code>
git clone https://github.com/rikkofjr/MatkulDeweb.git
</code>
<br/>
Setelah itu anda dapat langsung mempelajari setiap step pada video berikut.<br/>
<code>
https://www.youtube.com/playlist?list=PLwVLRbl_dCbXjz53V-nrB3TG8Fcqgn6Pc
</code>
<br/>
terimakasih, silahkan belajar
